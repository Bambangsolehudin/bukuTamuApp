

<?php $__env->startSection('content'); ?>
        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            
          </div>

          <?php if(count($errors) > 0): ?>
          <div class="alert alert-danger">
              <ul>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($error); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
          </div>
          <?php endif; ?>
          <!-- Content Row -->
          <div class="row justify-content-center">
              

                <div class="col-8">
                    <h5 class="text-center"><i class="fas fa-plus"></i>Edit Tamu</h5 class="text-center">
                    <form method="POST" action="<?php echo e(route('tamu.update', $item->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <div class="mb-3">
                          <label for="exampleInputtext1" class="form-label">Nama tamu</label>
                          <input type="text" name="nama" value="<?php echo e($item->nama); ?>" class="form-control" id="exampleInputtext1" aria-describedby="textHelp">
                        </div>
    
                        <div class="mb-3">
                            <label for="no_ktp" class="form-label">No KTP</label>
                            <input type="number" name="no_ktp" value="<?php echo e($item->no_ktp); ?>" class="form-control" id="no_ktp">
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" name="email" value="<?php echo e($item->email); ?>" class="form-control" id="email">
                        </div>

                        <div class="mb-3">
                            <label for="umur" class="form-label">Umur</label>
                            <input type="text" name="umur" value="<?php echo e($item->umur); ?>" class="form-control" id="umur">
                        </div>

                        <div class="mb-3">
                            <label for="jenis_kelamin" class="form-label">Jenis Kelamin</label>
                            <select name="jenis_kelamin" required class="form-control">
                                <option value="<?php echo e($item->jenis_kelamin); ?>">jangan diubah</option>
                                    <option value="laki-laki">
                                        Laki-laki
                                    </option>
                                    <option value="perempuan">
                                        Perempuan
                                    </option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="alamat" class="form-label">alamat</label>
                            <input type="text" value="<?php echo e($item->alamat); ?>" name="alamat" class="form-control" id="alamat">
                        </div>

                        <div class="mb-3">
                            <label for="tujuan_kunjungan" class="form-label">tujuan_kunjungan</label>
                            <input type="text" value="<?php echo e($item->tujuan_kunjungan); ?>" name="tujuan_kunjungan" class="form-control" id="tujuan_kunjungan">
                        </div>
                        <div class="mb-3">
                            <label for="foto" class="form-label">foto</label>
                            <input type="text" name="foto" value="<?php echo e($item->foto); ?>" class="form-control" id="foto">
                        </div>

                        <div class="mb-3">
                            <label for="status" class="form-label">status</label>
                            <select name="status" required class="form-control">
                                <option value="<?php echo e($item->status); ?>">Jangan dirubah</option>
                                    <option value="disetujui">
                                        disetujui
                                    </option>
                                    <option value="tidak disetujui">
                                        tidak disetujui
                                    </option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="jam" class="form-label">jam</label>
                            <input type="time" name="jam" value="<?php echo e($item->jam); ?>" class="form-control" id="jam">
                        </div>

                        <div class="mb-3">
                            <label for="tanggal" class="form-label">tanggal</label>
                            <input type="date" name="tanggal" value="<?php echo e($item->tanggal); ?>" class="form-control" id="tanggal">
                        </div>
                        
                       
                        <button type="submit" class="btn btn-primary">Submit</button>
                      </form>
                </div>
            </div>
        </div>
        <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECT\bukuTamuApp\resources\views/admin/tamu/edit.blade.php ENDPATH**/ ?>