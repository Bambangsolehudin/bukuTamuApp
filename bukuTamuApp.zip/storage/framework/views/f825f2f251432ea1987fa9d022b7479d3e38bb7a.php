<!DOCTYPE html>
<html>
<head>
    <title>Pemberitahuan</title>
     <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Pemberitahuan Tamu</div>

                <div class="panel-body">
                        
                        <p>nama : <?php echo e($tamu->nama); ?></p>
                        <p>status : <?php echo e($tamu->status); ?></p>
                        <?php if($tamu->status == 'disetujui'): ?>
                        <p>bertemu jam : <?php echo e($tamu->jam); ?></p>
                        <p>tanggal : <?php echo e($tamu->tanggal); ?></p>
                        <?php endif; ?>      

                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html><?php /**PATH E:\PROJECT\bukuTamuApp\resources\views/send.blade.php ENDPATH**/ ?>