

<?php $__env->startSection('content'); ?>
        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            
          </div>

          <!-- Content Row -->
          <div class="row justify-content-center">

              <div class="col-10">
                <div class="card shadow mb-4">
                    <div class="card-header">
                        <h6 class="m-0 font-weight-bold text-dark text-center">Data Tamu</h6>
                 
                    </div>
                    <div class="card-body">
                        <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                        <?php endif; ?>
                        <div class="table-responsive">
                            <a href="<?php echo e(route('tamu.create')); ?>" class="btn btn-primary"><i class="fas fa-plus"></i></a>
                            <table class="table table-bordered" id="pelanggan" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama</th>
                                        
                                        <th>tujuan kunjungan</th>
                                        <th>status</th>
                                        <th>aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $tamus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td> <a href="<?php echo e(route('tamu.show', $item->id)); ?>"><?php echo e($item->nama); ?></a></td>
                                        
                                        <td><?php echo e($item->tujuan_kunjungan); ?></td>
                                        <td><?php echo e($item->status); ?></td>




                                        <td>
                                            <a href="<?php echo e(route('tamu.edit', $item->id)); ?>" class="badge bg-warning text-dark"> <i class="fas fa-edit"></i></a>
                                            <form method="post" action="<?php echo e(route('tamu.destroy', $item->id)); ?>" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button type="submit" class="badge bg-danger text-white"><i class="fas fa-trash"></i></button>
                                            </form>
                                            <a href="<?php echo e(route('tamu.send', $item->id)); ?>" class="badge bg-dark text-white"> <i class="fas fa-share-square"></i></a>
                                        
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <td colspan="5">Data tidak ada</td>
                                    <?php endif; ?>
                              
                                </tbody>
                            </table>
                        </div>
                </div>
              </div>
                



          



        </div>
        <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECT\bukuTamuApp\resources\views/admin/tamu/index.blade.php ENDPATH**/ ?>